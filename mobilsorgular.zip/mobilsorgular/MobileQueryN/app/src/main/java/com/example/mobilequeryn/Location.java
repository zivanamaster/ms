package com.example.mobilequeryn;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;

public class Location implements Comparable, Serializable {

    public static ArrayList<Location> locations=new ArrayList<>();
    private String borough;
    private double latitude;
    private double longitude;
    private String zone;
    private int LocationID;

    public Location() {
    }

    public Location(String borough,int LocationID,double latitude, double longitude, String zone) {
        this.borough = borough;
        this.latitude = latitude;
        this.longitude = longitude;
        this.zone = zone;
        this.LocationID=LocationID;
        locations.add(this);
    }


    public int getLocationID() {
        return LocationID;
    }


    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }


    public String toString() {
        return LocationID+" "+borough+", "+zone;
    }

    public int compareTo(Object o) {
        Location location=(Location) o;
        return (Integer.compare(this.getLocationID(), location.getLocationID()));
    }
    @Override
    public boolean equals(Object o)
    {
        if(this == o)
            return true;
        if(!(o instanceof Location))
            return false;

        Location loc = (Location) o;
        return this.getLocationID() == loc.getLocationID();

    }

}
