package com.example.mobilequeryn;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Cap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Random;

import static com.example.mobilequeryn.MainActivity.ip;


public class Tip3Activity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnPolylineClickListener, GoogleMap.OnPolygonClickListener {
    Polyline polyline;
    Spinner spinnerGun;
    GoogleMap googleMap;
    Trip trip;
    Button btn;
    private RequestQueue mQueue;
    Location PU,DO;
    double PUlat,PUlong,DOlat,DOlong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip3);
        mQueue = Volley.newRequestQueue(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        spinnerGun=(Spinner) findViewById(R.id.spinnerGunler);

        ArrayList<String> gunler=new ArrayList<>();
        for(int i=1;i<=30;i++){
            gunler.add(i+" Aralık 2020");
        }

        ArrayAdapter<String> gunAdapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,gunler);
        spinnerGun.setAdapter(gunAdapter);

        DO=new Location("Manhattan",243,-74.01611967, 40.71161208,"Washington Heights North");
        PU=new Location("Queens",132,-73.77826366, 40.64260452,"JFK Airport");

         spinnerGun.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
             @Override
             public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 if(spinnerGun.getSelectedItem().toString().length()>0) {

                     String url = ip+"getLongestTrip/" + spinnerGun.getSelectedItem().toString();
                     JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                             new Response.Listener<JSONObject>() {
                                 @Override
                                 public void onResponse(JSONObject response) {
                                     try {
                                         JSONArray jsonArray = response.getJSONArray("response");

                                         JSONObject dropoff = jsonArray.getJSONObject(0).getJSONObject("dropoff");
                                         JSONObject pickup = jsonArray.getJSONObject(1).getJSONObject("pickup");

                                         PU = new Location(pickup.getString("borough"), pickup.getInt("LocationID"), pickup.getDouble("latitude"), pickup.getDouble("longitude"),
                                                 pickup.getString("zone"));
                                         DO = new Location(dropoff.getString("borough"), dropoff.getInt("LocationID"), dropoff.getDouble("latitude"), dropoff.getDouble("longitude"),
                                                 dropoff.getString("zone"));

                                     } catch (JSONException e) {
                                         e.printStackTrace();
                                     }
                                 }
                             }, new Response.ErrorListener() {
                         @Override
                         public void onErrorResponse(VolleyError error) {
                             error.printStackTrace();
                         }
                     });

                     mQueue.add(request);

                     PUlat = PU.getLatitude();
                     PUlong = PU.getLongitude();
                     DOlat = DO.getLatitude();
                     DOlong = DO.getLongitude();
                 }
             }

             @Override
             public void onNothingSelected(AdapterView<?> parent) {

             }
         });
    }

    Marker marker1,marker2;
    public void setPath(View view){
        if(polyline!=null){
            polyline.remove();
        }
        btn=(Button) view;
        if(marker1!=null && marker2!=null) {
            marker1.remove();
            marker2.remove();
            marker1.hideInfoWindow();
            marker2.hideInfoWindow();

        }


        LatLng pickup = new LatLng(PUlong,PUlat);
        LatLng dropoff = new LatLng(DOlong,DOlat);
/*
         new GetPathFromLocation(source, destination, new DirectionPointListener() {
                @Override
                public void onPath(PolylineOptions polyLine) {
                    googleMap.addPolyline(polyLine);
                }
            }).execute();



            LatLng origin=new LatLng(PUlat,PUlong);
*/
        polyline = googleMap.addPolyline(new PolylineOptions()
                .clickable(true)
                .add(
                        pickup,
                        dropoff)
        );
        polyline.setWidth(5);
        polyline.setTag("A");
        Random random=new Random();

        marker1=googleMap.addMarker(new MarkerOptions().position(pickup).title("PU:"+PU.toString()));
        marker2=googleMap.addMarker(new MarkerOptions().position(dropoff).title("DO:"+DO.toString()));
        marker1.showInfoWindow();
        marker2.showInfoWindow();
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(PUlong,DOlat),10));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap=googleMap;
    }


    @Override
    public void onPolygonClick(Polygon polygon) {

    }

    @Override
    public void onPolylineClick(Polyline polyline) {

    }
}


