package com.example.mobilequeryn;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

import static com.example.mobilequeryn.MainActivity.ip;

public class Tip2Activity extends AppCompatActivity {

    public static RecyclerView recyclerView;
    public static ArrayList<Trip> tip2yolculuk;
    TextView sonuc;
    public static TripAdapter tripsAdapter;
    ArrayList<Location> locations= MainActivity.locations;
    ArrayList<String> gunler=new ArrayList<>();
    Spinner spinnerLocation,spinnerFrom,spinnerTo;
    ArrayAdapter<String> gunAdapter;
    ArrayAdapter<Location> LocationAdapter;
    FragmentTransaction transaction;
    Button btn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip2);
        for(int i=1;i<=30;i++){
            gunler.add(String.valueOf(i));
        }
        spinnerFrom=(Spinner) findViewById(R.id.SpinnerFrom);
        spinnerTo=(Spinner) findViewById(R.id.SpinnerTo);
        spinnerLocation=(Spinner) findViewById(R.id.spinnerLocation);

        gunAdapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,gunler);
        spinnerFrom.setAdapter(gunAdapter);

        spinnerTo.setAdapter(gunAdapter);

        sonuc=findViewById(R.id.sonuctip2);


        Collections.sort(locations, (o1, o2) -> Integer.compare(o1.getLocationID(),o2.getLocationID()));

        LocationAdapter= new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Location.locations);
        LocationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        recyclerView =  findViewById(R.id.tip2nin);
        spinnerLocation.setAdapter(LocationAdapter);

        tripsAdapter = new TripAdapter(this,MainActivity.query2);
        recyclerView.setAdapter(tripsAdapter);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        spinnerLocation.setSelection(1);
        spinnerTo.setSelection(29);
        spinnerFrom.setSelection(0);


        spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    checking();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinnerFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                checking();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinnerTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                checking();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    int n=0;
    String url="";
    boolean hata=false;
    @SuppressLint("SetTextI18n")
    public void checking(){
        if (spinnerFrom.getSelectedItem().toString().length()>0&&spinnerLocation.getSelectedItem().toString().length()>0&& spinnerTo.getSelectedItem().toString().length()>0) {
            if (Integer.parseInt(spinnerTo.getSelectedItem().toString()) >= Integer.parseInt(spinnerFrom.getSelectedItem().toString())) {

                url=ip+spinnerLocation.getSelectedItem().toString().split(" ")[0]+"/"+
                        spinnerFrom.getSelectedItem().toString()+"/"+spinnerTo.getSelectedItem().toString();

                tip2yolculuk =MainActivity.jsonParseTrip2(url);
                hata=false;




            } else {
                hata=true;
                sonuc.setText("Alt sınır, üst sınırdan yüksek olamaz.");
                tip2yolculuk.clear();

            }
        } else {
            sonuc.setText("Tüm bilgileri seçiniz.");
            tip2yolculuk.clear();

        }
    }
    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
    public void send(View view){

            if(hata)
                sonuc.setText("Alt sınır, üst sınırdan yüksek olamaz.");
            else
                sonuc.setText("Toplamda " + tip2yolculuk.size() + " adet kayıt bulundu.");
            tripsAdapter = new TripAdapter(this, tip2yolculuk);
            recyclerView.setAdapter(tripsAdapter);
    }

}


