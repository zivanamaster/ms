package com.example.mobilequeryn;

import java.util.Date;

public class Trip implements Comparable{

    private int PULocationID,DOLocationID,RatecodeID,VendorID,passenger_count,payment_type;
    private double congestion_surcharge;
    private double fare_amount;
    private double tolls_amount;
    private double improvement_surcharge;
    private double trip_distance;
    private double extra;
    private double total_amount;
    private double mta_tax;
    private double tip_amount;
    private String store_and_fwd_flag;
    private String tpep_dropoff_datetime,tpep_pickup_datetime;
    private Location PULocation;
    private Location DOLocation;
    public Trip() {

    }

    public Trip(int PULocationID, int DOLocationID, int ratecodeID, int vendorID, int passenger_count, int payment_type, double congestion_surcharge, double fare_amount, double tolls_amount, double improvement_surcharge, double trip_distance, double extra, double total_amount, double mta_tax, double tip_amount, String store_and_fwd_flag, String tpep_dropoff_datetime, String tpep_pickup_datetime) {
        this.PULocationID = PULocationID;
        this.DOLocationID = DOLocationID;
        RatecodeID = ratecodeID;
        VendorID = vendorID;
        this.passenger_count = passenger_count;
        this.payment_type = payment_type;
        this.congestion_surcharge = congestion_surcharge;
        this.fare_amount = fare_amount;
        this.tolls_amount = tolls_amount;
        this.improvement_surcharge = improvement_surcharge;
        this.trip_distance = trip_distance;
        this.extra = extra;
        this.total_amount = total_amount;
        this.mta_tax = mta_tax;
        this.tip_amount = tip_amount;
        this.store_and_fwd_flag = store_and_fwd_flag;
        this.tpep_dropoff_datetime = tpep_dropoff_datetime;
        this.tpep_pickup_datetime = tpep_pickup_datetime;
        PULocation=Location.locations.get(PULocationID);
        DOLocation=Location.locations.get(DOLocationID);
    }

    public int getPULocationID() {

        return this.PULocationID;
    }
    public Location getPULocation() {

        return PULocation;
    }
    public Location getDOLocation() {
        return this.DOLocation;
    }

    public String passedTime(){
        String[] pickupday=tpep_pickup_datetime.split(" ")[0].split("-");
        String[] pickuptime=tpep_pickup_datetime.split(" ")[1].split(":");
        String[] dropoffday=tpep_dropoff_datetime.split(" ")[0].split("-");
        String[] dropofftime=tpep_dropoff_datetime.split(" ")[1].split(":");
        Date time1= new Date(Integer.valueOf(pickupday[0]), Integer.valueOf(pickupday[1]), Integer.valueOf(pickupday[2]), Integer.valueOf(pickuptime[0]), Integer.valueOf(pickuptime[1]));
        Date time2= new Date(Integer.valueOf(dropoffday[0]), Integer.valueOf(dropoffday[1]), Integer.valueOf(dropoffday[2]), Integer.valueOf(dropofftime[0]), Integer.valueOf(dropofftime[1]));

        long passed=Math.abs(time1.getTime()-time2.getTime());
        int minute=(int)(passed/60000);
        return String.valueOf(minute);


    }


    public String getVendorID() {
        if(VendorID==1){
            return "Creative Mobile Technologies";
        }else{
            return "VeriFone Inc.";
        }
    }

    public String getTpep_dropoff_datetime() {
        String[] dropoffday=tpep_dropoff_datetime.split(" ")[0].split("-");
        String dropofftime=tpep_dropoff_datetime.split(" ")[1];


        return dropoffday[2]+" Aralık 2020 "+ dropofftime;
    }
    public String getTpep_pickup_datetime() {
        String[] pickupday=tpep_pickup_datetime.split(" ")[0].split("-");
        String pickuptime=tpep_pickup_datetime.split(" ")[1];


        return pickupday[2]+" Aralık 2020 "+ pickuptime;
    }

    public String toString(){

        return getPULocationID()+" "+getPULocation().toString();
    }


    @Override
    public int compareTo(Object o) {
        Trip trip=(Trip) o;

        return (this.getTrip_distance() < trip.getTrip_distance() ? -1 :
                (this.getTrip_distance() == trip.getTrip_distance() ? 0 : 1));
    }
    public double getTrip_distance() {
        return trip_distance;
    }

    /***
     *
     *
     *
     * BURADAN SONRASINI KULLANMADIM
     *
     *
     * @return
     */
    public String getRatecodeID() {
        switch(RatecodeID){
            case 1:{
                return "Standard Rate";
            }
            case 2:{
                return "JFK";
            }
            case 3:{
                return "Newark";
            }
            case 4:{
                return "Nassau or Westchester";
            }
            case 5:{
                return "Negotiated fare";
            }
            case 6:{
                return "Group Ride";
            }
            default:{
                return "HATA";
            }
        }
    }

    public void setPULocationID(int PULocationID) {
        this.PULocationID = PULocationID;
    }

    public void setDOLocationID(int DOLocationID) {
        this.DOLocationID = DOLocationID;
    }

    public void setRatecodeID(int ratecodeID) {
        RatecodeID = ratecodeID;
    }

    public void setVendorID(int vendorID) {
        VendorID = vendorID;
    }

    public void setPassenger_count(int passenger_count) {
        this.passenger_count = passenger_count;
    }

    public void setPayment_type(int payment_type) {
        this.payment_type = payment_type;
    }

    public void setCongestion_surcharge(double congestion_surcharge) {
        this.congestion_surcharge = congestion_surcharge;
    }

    public void setFare_amount(double fare_amount) {
        this.fare_amount = fare_amount;
    }

    public void setTolls_amount(double tolls_amount) {
        this.tolls_amount = tolls_amount;
    }

    public void setImprovement_surcharge(double improvement_surcharge) {
        this.improvement_surcharge = improvement_surcharge;
    }

    public void setTrip_distance(double trip_distance) {
        this.trip_distance = trip_distance;
    }

    public void setExtra(double extra) {
        this.extra = extra;
    }

    public void setTotal_amount(double total_amount) {
        this.total_amount = total_amount;
    }

    public void setMta_tax(double mta_tax) {
        this.mta_tax = mta_tax;
    }

    public void setTip_amount(double tip_amount) {
        this.tip_amount = tip_amount;
    }

    public void setStore_and_fwd_flag(String store_and_fwd_flag) {
        this.store_and_fwd_flag = store_and_fwd_flag;
    }

    public void setTpep_dropoff_datetime(String tpep_dropoff_datetime) {
        this.tpep_dropoff_datetime = tpep_dropoff_datetime;
    }

    public void setTpep_pickup_datetime(String tpep_pickup_datetime) {
        this.tpep_pickup_datetime = tpep_pickup_datetime;
    }



    public void setPULocation(Location location){
        this.PULocation=location;

    }
    public void setDOLocation(Location location){
        this.DOLocation=location;

    }
    public int getDOLocationID() {
        return this.DOLocationID;
    }



    public int getPassenger_count() {
        return passenger_count;
    }

    public String getPayment_type() {
        switch (payment_type){
            case 1: {
                return "Kredi Kartı";
            }
            case 2:{
                return "Nakit";
            }
            case 3:{
                return "Ücret Alınmadı";
            }
            case 4:{
                return "Tartışma Yaşandı";
            }
            case 5:{
                return "Bilinmiyor";
            }
            case 6:{
                return "Geçersiz Yolculuk";
            }
            default:{
                return "HATA";
            }
        }
    }

    public double getCongestion_surcharge() {
        return congestion_surcharge;
    }
    public double getFare_amount() {
        return fare_amount;
    }

    public double getTolls_amount() {
        return tolls_amount;
    }

    public double getImprovement_surcharge() {
        return improvement_surcharge;
    }



    public double getExtra() {
        return extra;
    }

    public double getTotal_amount() {
        return total_amount;
    }

    public double getMta_tax() {
        return mta_tax;
    }

    public double getTip_amount() {
        return tip_amount;
    }

    public String getStore_and_fwd_flag() {
        if(store_and_fwd_flag.equals("Y")){
            return "Evet";
        }
        else{
            return "Hayır";
        }
    }


    public int getDay(){
        String[] dropoffday=tpep_dropoff_datetime.split(" ")[0].split("-");
        return Integer.valueOf(dropoffday[2]);
    }


}
