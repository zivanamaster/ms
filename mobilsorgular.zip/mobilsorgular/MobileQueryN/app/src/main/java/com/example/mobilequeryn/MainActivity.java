package com.example.mobilequeryn;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

import static com.example.mobilequeryn.Tip2Activity.recyclerView;
import static com.example.mobilequeryn.Tip2Activity.tripsAdapter;

public class MainActivity extends AppCompatActivity {

    public static final String ip="http://192.168.1.33:3000/";
    private TextView mTextViewResult;
    private static RequestQueue mQueue;
    public static ArrayList<Trip> query1=new ArrayList<>();
    public static ArrayList<Trip> query2=new ArrayList<>();
    public static ArrayList<Location> locations=new ArrayList<>();

    ProgressBar progressBar;
    Handler mHandler=new Handler();
    int progressStatus=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar=findViewById(R.id.progressBar);

        mTextViewResult = findViewById(R.id.text_view_result);
        Button buttonParse = findViewById(R.id.button_parse);
        mQueue = Volley.newRequestQueue(this);

        LocationlariAl();

        buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                query1=jsonParseTrip(ip+"get-longest-distances");
                query2=jsonParseTrip2(ip+"1/1/30");
                Intent intent = new Intent(MainActivity.this,MenuActivity.class);
                startActivity(intent);
            }
        });


    }


    void LocationlariAl() {


        String url=ip+"locations";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("response");

                            for (int i = 0; i<jsonArray.length(); i++){
                                JSONObject location = jsonArray.getJSONObject(i);

                                new Location(location.getString("borough"),location.getInt("LocationID")
                                        ,location.getDouble("latitude"),location.getDouble("longitude"),location.getString("zone"));

                            }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            error.printStackTrace();
        }
    });

                mQueue.add(request);

}

    public static ArrayList<Trip> jsonParseTrip(String url){
        ArrayList<Trip> array=new ArrayList<>();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("response");

                            for (int i = 0; i<jsonArray.length(); i++){
                                JSONObject yolculuklar = jsonArray.getJSONObject(i);


                                array.add(new Trip(yolculuklar.getInt("PULocationID"),
                                        yolculuklar.getInt("DOLocationID"),
                                        yolculuklar.getInt("RatecodeID") ,
                                        yolculuklar.getInt("VendorID"),
                                        yolculuklar.getInt("passenger_count"),
                                        yolculuklar.getInt("payment_type"),
                                        yolculuklar.getDouble("congestion_surcharge") ,
                                        yolculuklar.getDouble("fare_amount"),
                                        yolculuklar.getDouble("tolls_amount"),
                                        yolculuklar.getDouble("improvement_surcharge"),
                                        yolculuklar.getDouble("trip_distance"),
                                        yolculuklar.getDouble("extra"),
                                        yolculuklar.getDouble("total_amount"),
                                        yolculuklar.getDouble("mta_tax"),
                                        yolculuklar.getDouble("tip_amount"),
                                        yolculuklar.getString("store_and_fwd_flag"),
                                        yolculuklar.getString("tpep_dropoff_datetime") ,
                                        yolculuklar.getString("tpep_pickup_datetime") ));



                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);

        return array;
    }

    public static ArrayList<Trip> jsonParseTrip2(String url){

        ArrayList<Trip> array2=new ArrayList<>();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("response");

                            for (int i = 0; i<jsonArray.length(); i++){
                                JSONObject yolculuklar = jsonArray.getJSONObject(i);


                                array2.add(new Trip(yolculuklar.getInt("PULocationID"),
                                        yolculuklar.getInt("DOLocationID"),
                                        yolculuklar.getInt("RatecodeID") ,
                                        yolculuklar.getInt("VendorID"),
                                        yolculuklar.getInt("passenger_count"),
                                        yolculuklar.getInt("payment_type"),
                                        yolculuklar.getDouble("congestion_surcharge") ,
                                        yolculuklar.getDouble("fare_amount"),
                                        yolculuklar.getDouble("tolls_amount"),
                                        yolculuklar.getDouble("improvement_surcharge"),
                                        yolculuklar.getDouble("trip_distance"),
                                        yolculuklar.getDouble("extra"),
                                        yolculuklar.getDouble("total_amount"),
                                        yolculuklar.getDouble("mta_tax"),
                                        yolculuklar.getDouble("tip_amount"),
                                        yolculuklar.getString("store_and_fwd_flag"),
                                        yolculuklar.getString("tpep_dropoff_datetime") ,
                                        yolculuklar.getString("tpep_pickup_datetime") ));
                            }
                        } catch (JSONException e) {

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        request.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        mQueue.add(request);
        query2=array2;
        return array2;
    }


}