package com.example.mobilequeryn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.TripViewHolder> {

    ArrayList<Trip> mTripList;
    LayoutInflater inflater;

    public TripAdapter(Context context, ArrayList<Trip> trips) {
        inflater = LayoutInflater.from(context);
        this.mTripList = trips;
    }



    @Override
    public TripViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.tip1_list_item, parent, false);
        TripViewHolder holder = new TripViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(TripViewHolder holder, int position) {
        Trip selectedTrip = mTripList.get(position);
        holder.setData(selectedTrip, position);

    }


    @Override
    public int getItemCount() {
        return mTripList.size();
    }


    class TripViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView txtId;
        private TextView txt_vendor;
        private TextView txtPU;
        private TextView txtDO;
        private TextView txt_passenger;
        private TextView txt_distance;
        private TextView txtPU_time;
        private TextView txtDO_time;
        private TextView txt_rateCode;
        private TextView txt_payment_type;
        private TextView txt_fare_amount;
        private TextView txt_extra;
        private TextView txt_mta_tax;
        private TextView txt_improvement_surcharge;
        private TextView txt_tip;
        private TextView txt_tolls_amount;
        private TextView txt_total;
        private TextView txt_storeandfwd_flag;
        private TextView txt_congestion_surcharge;
        private TextView txt_passed_time;
        private String key;

        public TripViewHolder(View itemView) {
            super(itemView);
            txt_vendor= itemView.findViewById(R.id.txt1_vendor);
            txtPU=itemView.findViewById(R.id.txt1_pickup);
            txtDO=itemView.findViewById(R.id.txt1_dropoff);
            txtPU_time=itemView.findViewById(R.id.txt1_pickuptime);
            txtDO_time=itemView.findViewById(R.id.txt1_dropofftime);
            txt_distance=itemView.findViewById(R.id.txt1_distance);
            txt_passed_time=itemView.findViewById(R.id.txt1_passedtime);


        }

        public void setData(Trip trip, int position) {
                    txt_vendor.setText(String.valueOf(trip.getVendorID()));
                    txtPU.setText(trip.getPULocation().toString());
                    txtDO.setText(trip.getDOLocation().toString());
                    txtPU_time.setText(String.valueOf(trip.getTpep_pickup_datetime()));
                    txtDO_time.setText(String.valueOf(trip.getTpep_dropoff_datetime()));
                    txt_passed_time.setText(trip.passedTime()+" Dakika");
                    txt_distance.setText(String.valueOf(trip.getTrip_distance())+" mil");
        }


        @Override
        public void onClick(View v) {


        }


    }
}