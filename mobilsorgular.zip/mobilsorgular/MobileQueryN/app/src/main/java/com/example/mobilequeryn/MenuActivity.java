package com.example.mobilequeryn;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MenuActivity extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
    public void Tip1Act(View view){

        Intent intent=new Intent(this, Tip1Activity.class);
        startActivity(intent);
    }
    public void Tip2Act(View view){

        Intent intent=new Intent(this, Tip2Activity.class);
        startActivity(intent);
    }
    public void Tip3Act(View view){

        Intent intent=new Intent(this, Tip3Activity.class);
        startActivity(intent);
    }




}
