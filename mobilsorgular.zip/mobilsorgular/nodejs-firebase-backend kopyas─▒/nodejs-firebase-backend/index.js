const express = require('express');
const admin = require('firebase-admin');
const SERVICE_ACCOUNT = require("./firebase-service-account.json");

const app = express();

admin.initializeApp({
    credential: admin.credential.cert(SERVICE_ACCOUNT),
    databaseURL: "https://mobilequeryn-default-rtdb.firebaseio.com/"
});

const db = admin.database();
const locationsCollection = db.ref('/0/locations/');
const tripsCollection = db.ref('/1/trips');
const PORT = 3000;

app.get('/', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date() })
});


app.get('/locations', async(req, res) => {
    let response = [];

    await locationsCollection
        .once('value', async(snapshot) => {
            const data = await snapshot.val();
            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    response.push(data[prop]);
                }
            }
        });

    res.json({ response });
});

app.get('/yolculuklar', async(req, res) => {
    let response = [];

    await tripsCollection
        .once('value', async(snapshot) => {
            const data = await snapshot.val();
            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    response.push(data[prop]);
                }
            }
        });

    res.json({ response });
});

/*
    QUERY 1
    @ SQL Version: select * from tripsCollection
                    order by trip_distance desc
                    limit 5;
*/
app.get('/get-longest-distances', async(req, res) =>  {
    let response = [];

    await tripsCollection
        .orderByChild('trip_distance')
        .limitToLast(5)
        .once('value', async(snapshot) => {
            const data = await snapshot.val();
            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    response.push(data[prop]);
                }
            }
        });

    res.json({ response });
});

/*
    QUERY 2
    @ SQL Version: select * from tripsCollection
                    where PULocationID = locationId;
*/
app.get('/:locationId/:startDay/:endDay', async(req, res) =>  {
    let response = [];
    const locationId = req.params.locationId;
    const startDay = req.params.startDay;
    const endDay = req.params.endDay;

    await tripsCollection
        .orderByChild('PULocationID')
        .equalTo(parseInt(locationId))
        .once('value', async(snapshot) => {
            const data = await snapshot.val();

            if (data === null) {
                return response.push({ fail: 'fail' });
            }

            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    const day = data[prop].tpep_pickup_datetime.split(' ')[0].split('-')[2];
                    if (day >= parseInt(startDay) && day <= parseInt(endDay)) {
                        response.push(data[prop]);
                    }
                }
            }

        });

    res.json({ count: response.length, response });
});

/*
    QUERY 3
*/
app.get('/getLongestTrip/:day', async(req, res) =>  {
    let response = [];
    const selectedDay = req.params.day;
    let dropOffLocationId, pickUpLocationId;

    if (selectedDay > 31 || selectedDay < 0) {
        return res.json({ message: 'day invalid' });
    }

    await tripsCollection
        .once('value', async(snapshot) => {
            const data = await snapshot.val();

            if (data === null) {
                response.push({ fail: 'fail' });
                return res.json(response);
            }

            let max;
            let longestTrip;
            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    const day = data[prop].tpep_pickup_datetime.split(' ')[0].split('-')[2];
                    if (parseInt(day) === parseInt(selectedDay)) {
                        if (!max || data[prop].trip_distance > max) {
                            max = data[prop].trip_distance;
                            longestTrip = data[prop];
                        }
                    }
                }
            }

            if (longestTrip) {
                dropOffLocationId = longestTrip.DOLocationID;
                pickUpLocationId = longestTrip.PULocationID;
            }
        });

    if (!dropOffLocationId || !pickUpLocationId) {
        return res.json({ message: 'trip not found' });
    }

    await locationsCollection
        .orderByChild('LocationID')
        .equalTo(dropOffLocationId)
        .once('value', async(snapshot) => {
            const data = await snapshot.val();
            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    response.push({ dropoff: data[prop] });
                }
            }
        });

    await locationsCollection
        .orderByChild('LocationID')
        .equalTo(pickUpLocationId)
        .once('value', async(snapshot) => {
            const data = await snapshot.val();
            for (const prop in data) {
                if (data.hasOwnProperty(prop)) {
                    response.push({ pickup: data[prop] });
                }
            }
        });

    res.json({response});
});


app.listen(PORT);